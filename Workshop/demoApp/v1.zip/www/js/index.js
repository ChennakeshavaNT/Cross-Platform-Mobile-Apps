function abc(){
    window.location.href="menu.html";
}